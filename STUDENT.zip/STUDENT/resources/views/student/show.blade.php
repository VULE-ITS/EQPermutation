@extends('student.layout')
@section('content')

<div class="card" style="margin:20px;">
    <div class="card-header">Students Page</div>
    <div class="card-body">
        <div class="card-body">
            <h5 class="card-title">Name : {{ $student->name }}</h5>
            <p class="card-text">Address : {{ $student->add }}</p>

        </div>
        </hr>
    </div>
    @endsection