
<?php $__env->startSection('content'); ?>
<div class="card" style="margin:20px;">
    <div class="card-header">Create New Students</div>
    <div class="card-body">
        <form action="<?php echo e(url('student')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <label>Name</label></br>
            <input type="text" name="name" id="name" class="form-control"></br>
            <label>Address</label></br>
            <input type="text" name="add" id="add" class="form-control"></br>
            <input type="submit" value="Save" class="btn btn-success"></br>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp6\htdocs\STUDENT\resources\views/student/create.blade.php ENDPATH**/ ?>