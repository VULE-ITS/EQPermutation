
<?php $__env->startSection('content'); ?>

<div class="card" style="margin:20px;">
    <div class="card-header">Edit Student</div>
    <div class="card-body">

        <form action="<?php echo e(url('student/' .$students->id)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <?php echo method_field("PATCH"); ?>
            <input type="hidden" name="name" id="id" value="<?php echo e($students->id); ?>" id="id" />
            <label>Name</label></br>
            <input type="text" name="name" id="name" value="<?php echo e($students->name); ?>" class="form-control"></br>
            <label>Address</label></br>
            <input type="text" name="add" id="add" value="<?php echo e($students->address); ?>" class="form-control"></br>
            <input type="submit" value="Update" class="btn btn-success"></br>
        </form>

    </div>
</div>
<?php echo $__env->make('student.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp6\htdocs\STUDENT\resources\views/student/edit.blade.php ENDPATH**/ ?>