
<?php $__env->startSection('content'); ?>

<div class="card" style="margin:20px;">
    <div class="card-header">Students Page</div>
    <div class="card-body">
        <div class="card-body">
            <h5 class="card-title">Name : <?php echo e($student->name); ?></h5>
            <p class="card-text">Address : <?php echo e($student->add); ?></p>

        </div>
        </hr>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp6\htdocs\STUDENT\resources\views/student/show.blade.php ENDPATH**/ ?>