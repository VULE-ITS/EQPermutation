﻿using GroupDocs.Viewer;
using GroupDocs.Viewer.Options;
using Microsoft.AspNetCore.Mvc;
using Readfilepdf.Models;
using System.Diagnostics;

namespace Readfilepdf.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [HttpPost]
        public ActionResult ViewDocument()
        {
            string filename = Request.Form["FiletoView"];
            string Ouput = ("sour");
            string path = Path.Combine(Ouput, "sour.pdf");
            using (Viewer v=new Viewer("sour/"+filename))
            {
              PdfViewOptions option=new PdfViewOptions(path);
                v.View(option);
            }
            var stream = new FileStream("sour/" + "sour.pdf",
                FileMode.Open,
                    FileAccess.Read
                );
            var fResult = new FileStreamResult(stream, "application/pdf");
            return fResult;

              //  return View();
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}